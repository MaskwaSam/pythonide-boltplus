PYTHON IDE + BOLT+ — MOODLE PACKAGE

1. In your Moodle course, turn Edit mode on and add a File resource.
   Use a new resource for this test so the previous version stays available.
2. Upload pythonide-boltplus-display-library-moodle-20261104.zip into Select files.
3. Click the ZIP in Moodle and choose Unzip.
4. Click index.html and choose Set main file.
5. Set Appearance > Display to Open, then Save and display.

Keep all five extracted files together at the same level:
index.html, python-worker.js, toybox.js, core-4.6.0.wasm, README-MOODLE.txt.
The IDE and Sphero SDK scripts are bundled inside index.html.
This is a File resource ZIP, not a Moodle course backup.

On a Chromebook, open the HTTPS Moodle resource in Chrome. Internet is
required for the Python runtime and optional CodeMirror editor CDN.
Close other Sphero apps/tabs. Connect BOLT+, confirm the green dot, aim,
then run the starter on a clear floor. Wait two minutes after it finishes;
disconnect, reconnect, aim again, and rerun. Classroom testing remains
separate from the successful Mac test and local browser checks.

The working async starter, aiming, Neo reconnect repair, and idle
battery/sleep-warning maintenance are preserved from the current app.
Sphero SDK code is third-party code from the user-supplied archive;
no new license is granted here. The archive did not supply the LICENSE.txt
files referenced by its bundle headers. Original worker header retained.


EMOJI + ANIMATIONS LIBRARY (November 4 local build)
Use Emoji + animations to search the supplied Sphero app's 649 images
(including 58 emoji graphics) and 77 built-in animations, plus random choices.
Choose Use example, then connect/aim and Run. Names and DisplayImage /
DisplayAnimation constants work alongside numeric IDs. Thumbnails are embedded
in index.html; there are no extra preview files to upload. Custom GIF uploads,
URLs and arbitrary Unicode emoji text are not supported. The source catalogue
does not establish newer firmware asset coverage or physical display output.


CSE1240 commands are explicitly async: import them from sphero and await
set_heading, roll_to_distance, stop_roll, set_main_led, set_display_text,
get_ambient_light and delay. roll_to_distance uses centimetres and a whole
raw speed from 0 to 255; raw 25 is not 25 percent. It waits for the native
firmware distance-completion notification, not a timed approximation.
get_ambient_light stops first and waits for a fresh valid sensor packet.
Stop/error cleanup finishes before another run. An uncertain distance move
requires disconnect/reconnect before more motion; old completion packets
must never finish a later move. This software behavior still needs physical
Chromebook/BOLT+ distance, display, sensor and recovery acceptance.
