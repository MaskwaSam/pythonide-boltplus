PYTHON IDE + BOLT+ — MOODLE PACKAGE

1. In your Moodle course, turn Edit mode on and add a File resource.
   Use a new resource for this test so the previous version stays available.
2. Upload pythonide-boltplus-moodle.zip into Select files.
3. Click the ZIP in Moodle and choose Unzip.
4. Click index.html and choose Set main file.
5. Set Appearance > Display to Open, then Save and display.

Keep all five extracted files together at the same level:
index.html, python-worker.js, toybox.js, core-4.6.0.wasm, README-MOODLE.txt.
The IDE and Sphero SDK scripts are bundled inside index.html.
This is a File resource ZIP, not a Moodle course backup.

On a Chromebook, open the HTTPS Moodle resource in Chrome. Internet is
required for the Python runtime and optional CodeMirror editor CDN.
Close other Sphero apps/tabs. Connect BOLT+, confirm the green dot, aim,
then run the starter on a clear floor. Wait two minutes after it finishes;
disconnect, reconnect, aim again, and rerun. Classroom testing remains
separate from the successful Mac test and local browser checks.

The working async starter, aiming, Neo reconnect repair, and idle
battery/sleep-warning maintenance are preserved from the current app.
Sphero SDK code is third-party code from the user-supplied archive;
no new license is granted here. The archive did not supply the LICENSE.txt
files referenced by its bundle headers. Original worker header retained.
